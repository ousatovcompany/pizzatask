package com.example.ousatov.pizzatask;


public class FSVenue {
    private String mName;
    private int mDistance;

    public FSVenue() {
        mName = "";
        mDistance = -1;
    }

    public int getDistance() {
        return mDistance;
    }

    public void setDistance(int d) {
        mDistance = d;
    }

    public void setName(String n) {
        mName = n;
    }

    public String getName() {
        return mName;
    }
}
