package com.example.ousatov.pizzatask.networking;


import android.os.AsyncTask;
import android.util.Log;

import com.example.ousatov.pizzatask.FSVenue;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;

import retrofit.GsonConverterFactory;
import retrofit.Retrofit;
import retrofit.RxJavaCallAdapterFactory;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class FSCommunication {
    private static final String TAG = "US";

    final private String CLIENT_ID = "F3X4K30EJF0ES3LACQ2FRT4QWMJGGRNFRGWCCEWXR2O4HTRG";
    final private String CLIENT_SECRET = "UBVEJPUF0532QUMMBBVQTPNDA5MMUCKJFFHGHQPISUNBLABV";

    private FSService mFsService;
    public FSCommunication() {
        mFsService = createRetrofitService(FSService.class, FSService.FS_SERVER_BASE_URL);
    }

    public void getVenuesFromFoursquare(String version, String  ll, String query, int limit) {
        mFsService.getVenues(CLIENT_ID, CLIENT_SECRET, version, ll, query, limit)
                .subscribeOn(Schedulers.from(AsyncTask.THREAD_POOL_EXECUTOR))
                .observeOn(Schedulers.from(AsyncTask.THREAD_POOL_EXECUTOR))
                .subscribe(new Subscriber<JsonObject>() {
                    @Override
                    public void onCompleted() {
                        Log.d(TAG, "onCompleted() called");
                        Log.d(TAG, "onCompleted!!!!! tid = " + Thread.currentThread().getId());
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.d(TAG, "onError() called " + e.getMessage());
                        Log.d(TAG, "onError!!!!! tid = " + Thread.currentThread().getId());
                    }

                    @Override
                    public void onNext(JsonObject jsonObject) {
                        Log.d(TAG, "onNext!!!!! tid = " + Thread.currentThread().getId());
                        if (jsonObject.has("response")) {
                            Log.d(TAG, "jsonObject.has(\"response\") !!!");
                            if (jsonObject.getAsJsonObject("response").has("venues")) {
                                JsonArray jsonArray = jsonObject.getAsJsonObject("response").getAsJsonArray("venues");
                                Log.d(TAG, "jsonArray size = " + jsonArray.size());
                            }
                        }
                    }
                });
        Log.d(TAG, "getVenuesFromFoursquare() end");
    }


    static <T> T createRetrofitService(final Class<T> clazz, final String endPoint) {
        Log.d(TAG, "Service interface: " + clazz + " Service end point: " + endPoint);
        final Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(endPoint)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
        return retrofit.create(clazz);
    }
}
